
maxiter = 20;
restartProb = 0.50;
%dim_drug = 100;
%dim_prot = 400;
dim_dis = 400;
dim_lnc = 100;

%drugNets = {'Sim_mat_drug_drug', 'Sim_mat_drug_disease', 'Sim_mat_drug_se', 'Sim_mat_Drugs'};
%proteinNets = {'Sim_mat_protein_protein', 'Sim_mat_protein_disease', 'Sim_mat_Proteins'};



tic
%X = DCA(drugNets, dim_drug, restartProb, maxiter);
Dis_feature = load('E:\zhangmingrui\Matlab\Two\feature\dis_vvector.txt');
% X = DCA(Dis_feature, dim_drug, restartProb, maxiter);
X = DCA(Dis_feature, dim_dis);
toc
tic
%Y = DCA(proteinNets, dim_prot, restartProb, maxiter);
Lnc_feature = load('E:\zhangmingrui\Matlab\Two\feature\lnc_vvector.txt');
% Y = DCA(proteinNets, dim_prot, restartProb, maxiter);
Y = DCA(Lnc_feature, dim_lnc);

toc

%dlmwrite(['E:\zhangmingrui\Matlab\DTINet-master\feature\drug_vector_d', num2str(dim_drug), '.txt'], X, '\t');
%dlmwrite(['E:\zhangmingrui\Matlab\DTINet-master\feature\protein_vector_d', num2str(dim_prot), '.txt'], Y, '\t');
dlmwrite(['E:\zhangmingrui\Matlab\Two\feature\dis_vector_d', num2str(dim_dis), '.txt'], X, '\t');
dlmwrite(['E:\zhangmingrui\Matlab\Two\feature\lnc_vector_d', num2str(dim_lnc), '.txt'], Y, '\t');
