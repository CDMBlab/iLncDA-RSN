function [X] = run_RWR(networks, rsp, maxiter)
	Q = [];
	for i = 1 : length(networks)
		fileID = char(strcat('E:\zhangmingrui\Matlab\Two\network\', networks(i), '.txt'));
		net = load(fileID);
		tQ = diffusionRWR(net, maxiter, rsp);
		Q = [Q, tQ];
        X = Q;
	end

	%nnode = size(Q, 1);
	%alpha = 1 / nnode;
	%Q = log(Q + alpha) - log(alpha);

	%Q = Q * Q';
	%[U, S] = svds(Q, dim);	
	%X = U * sqrt(sqrt(S));
end
