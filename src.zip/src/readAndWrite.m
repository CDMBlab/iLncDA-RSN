maxiter = 20;
restartProb = 0.50;
dim_drug = 100;
dim_prot = 400;

diseaseNets = {'Sim_disease_gip', 'Sim_disease_semantic', 'Sim_disease-lncRNA_association', 'Sim_disease-miRNA_association'};
lncRNANets = {'Sim_lncRNA_functional', 'Sim_lncRNA_gip', 'Sim_lncRNA-disease_association','Sim_lncRNA-miRNA_association'};


tic
X = run_RWR(diseaseNets, restartProb, maxiter);
toc
tic
Y = run_RWR(lncRNANets, restartProb, maxiter);
toc

dlmwrite(['E:\zhangmingrui\Matlab\Two\feature\disesase_vector.txt'], X, '\t');
dlmwrite(['E:\zhangmingrui\Matlab\Two\feature\lncRNA_vector.txt'], Y, '\t');